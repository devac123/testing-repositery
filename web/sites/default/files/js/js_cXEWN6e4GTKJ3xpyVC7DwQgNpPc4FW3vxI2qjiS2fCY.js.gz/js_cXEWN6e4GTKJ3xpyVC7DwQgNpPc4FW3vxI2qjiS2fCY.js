Drupal.behaviors.behaviorName = {    
    attach: function (context, settings) {   
        console.log('shiv')   
    //   // Custom code to be run on page load and on Ajax load
    //   $('.element-example', context).click(function () {        
    //     $(this).next('ul').toggle('show');      
    //   });
  
    }
  
  };;
